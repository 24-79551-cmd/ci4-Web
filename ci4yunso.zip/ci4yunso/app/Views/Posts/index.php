<h2>Posts</h2>
<a href="<?= site_url('posts/new') ?>">Create New Post</a>

<?php if (session()->getFlashdata('message')): ?>
<p><?= esc(session()->getFlashdata('message')) ?></p>
<?php endif; ?>

<table border="1" cellpadding="8">
<tr>
<th>ID</th>
<th>Content</th>
<th>Created By</th>
<th>Title</th>
<th>Actions</th>
</tr>
<?php foreach ($posts as $post): ?>
<tr>
<td><?= esc($post['id']) ?></td>
<td><?= esc($post['content']) ?></td>
<td><?= esc($post['created_by']) ?></td>
<td><?= esc($post['title']) ?></td>
<td>
<a href="<?= site_url('posts/' . $post['id'] . '/edit') ?>">Edit</a>
<form action="<?= site_url('posts/' . $post['id']) ?>" method="post" style="display:inline;">
<?= csrf_field() ?>
<input type="hidden" name="_method" value="DELETE">
<button type="submit" onclick="return confirm('Delete this post?')">Delete</button>
</form>
</td>
</tr>
<?php endforeach; ?>
</table>

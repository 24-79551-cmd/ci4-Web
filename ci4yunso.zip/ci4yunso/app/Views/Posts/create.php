<h2>Create Post</h2>

<?php if (session()->getFlashdata('errors')): ?>
<ul>
<?php foreach (session()->getFlashdata('errors') as $error): ?>
<li><?= esc($error) ?></li>
<?php endforeach; ?>
</ul>
<?php endif; ?>

<form action="<?= site_url('posts') ?>" method="post">
<?= csrf_field() ?>
<div>
<label>Title</label><br>
<input type="text" name="title" value="<?= old('title') ?>">
</div>
<div>
<label>Created By</label><br>
<input type="text" name="created_by" value="<?= old('created_by') ?>">
</div>
<div>
<label>Content</label><br>
<textarea name="content"><?= old('content') ?></textarea>
</div>
<button type="submit">Save</button>
</form>

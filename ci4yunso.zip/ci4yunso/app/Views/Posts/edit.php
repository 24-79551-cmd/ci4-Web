<h2>Edit Post</h2>

<form action="<?= site_url('posts/' . $post['id']) ?>" method="post">
<?= csrf_field() ?>
<input type="hidden" name="_method" value="PUT">
<div>
<label>Title</label><br>
<input type="text" name="title" value="<?= old('title', esc($post['title'])) ?>">
</div>
<div>
<label>Created By</label><br>
<input type="text" name="created_by" value="<?= old('created_by', esc($post['created_by'])) ?>">
</div>
<div>
<label>Content</label><br>
<textarea name="content"><?= old('content', esc($post['content'])) ?></textarea>
</div>
<button type="submit">Update</button>
</form>

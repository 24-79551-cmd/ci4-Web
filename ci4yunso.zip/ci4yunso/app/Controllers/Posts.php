<?php

namespace App\Controllers;

use App\Models\PostsModel;
use CodeIgniter\HTTP\ResponseInterface;
use CodeIgniter\RESTful\ResourceController;

class Posts extends ResourceController
{
    protected $modelName = PostsModel::class;

    /**
     * Return an array of resource objects, themselves in array format.
     *
     * @return ResponseInterface
     */
    public function index()
    {
        $posts = $this->model->getPosts();

        return view('Posts/index', ['posts' => $posts]);
    }

    /**
     * Return the properties of a resource object.
     *
     * @param int|string|null $id
     *
     * @return ResponseInterface
     */
    public function show($id = null)
    {
        $post = $this->model->getPosts($id);

        if ($post === null) {
            return redirect()->to('/posts')->with('message', 'Post not found.');
        }

        return view('Posts/index', ['posts' => [$post]]);
    }

    /**
     * Return a new resource object, with default properties.
     *
     * @return ResponseInterface
     */
    public function new()
    {
        return view('Posts/create');
    }

    /**
     * Create a new resource object, from "posted" parameters.
     *
     * @return ResponseInterface
     */
    public function create()
    {
        $rules = [
            'title' => 'required|min_length[3]|max_length[255]',
            'created_by' => 'required|min_length[3]|max_length[255]',
            'content' => 'required|min_length[5]',
        ];

        if (! $this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $data = [
            'title' => $this->request->getPost('title'),
            'created_by' => $this->request->getPost('created_by'),
            'content' => $this->request->getPost('content'),
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
        ];

        $this->model->insert($data);

        return redirect()->to('/posts')->with('message', 'Post created successfully.');
    }

    /**
     * Return the editable properties of a resource object.
     *
     * @param int|string|null $id
     *
     * @return ResponseInterface
     */
    public function edit($id = null)
    {
        $post = $this->model->find($id);

        if ($post === null) {
            return redirect()->to('/posts')->with('message', 'Post not found.');
        }

        return view('Posts/edit', ['post' => $post]);
    }

    /**
     * Add or update a model resource, from "posted" properties.
     *
     * @param int|string|null $id
     *
     * @return ResponseInterface
     */
    public function update($id = null)
    {
        $post = $this->model->find($id);

        if ($post === null) {
            return redirect()->to('/posts')->with('message', 'Post not found.');
        }

        $rules = [
            'title' => 'required|min_length[3]|max_length[255]',
            'created_by' => 'required|min_length[3]|max_length[255]',
            'content' => 'required|min_length[5]',
        ];

        if (! $this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $data = [
            'title' => $this->request->getPost('title'),
            'created_by' => $this->request->getPost('created_by'),
            'content' => $this->request->getPost('content'),
            'updated_at' => date('Y-m-d H:i:s'),
        ];

        $this->model->update($id, $data);

        return redirect()->to('/posts')->with('message', 'Post updated successfully.');
    }

    /**
     * Delete the designated resource object from the model.
     *
     * @param int|string|null $id
     *
     * @return ResponseInterface
     */
    public function delete($id = null)
    {
        if ($this->model->find($id) === null) {
            return redirect()->to('/posts')->with('message', 'Post not found.');
        }

        $this->model->delete($id);

        return redirect()->to('/posts')->with('message', 'Post deleted successfully.');
    }
}

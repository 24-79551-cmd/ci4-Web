<?php

use CodeIgniter\Router\RouteCollection;

/** @var RouteCollection $routes */
$routes->get('/home/i/uh/index', 'Home::index');

$routes->get('/students', 'Students::index');
$routes->resource('posts');

$routes->get('create', 'Posts::create');